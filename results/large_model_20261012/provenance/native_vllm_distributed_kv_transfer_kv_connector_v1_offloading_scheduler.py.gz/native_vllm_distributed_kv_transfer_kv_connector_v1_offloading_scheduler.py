# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from itertools import islice
import json
import time
from typing import Any, NamedTuple

from vllm.distributed.kv_events import BlockRemoved, BlockStored, KVCacheEvent
from vllm.distributed.kv_transfer.kv_connector.utils import yield_req_data
from vllm.distributed.kv_transfer.kv_connector.v1.base import KVConnectorMetadata
from vllm.distributed.kv_transfer.kv_connector.v1.offloading.common import (
    OffloadingConnectorMetadata,
    OffloadingWorkerMetadata,
    ReqId,
    TransferJob,
)
from vllm.logger import init_logger
from vllm.utils.math_utils import cdiv
from vllm.v1.core.kv_cache_manager import KVCacheBlocks
from vllm.v1.core.sched.output import SchedulerOutput
from vllm.v1.kv_cache_interface import (
    FullAttentionSpec,
    KVCacheSpec,
    MambaSpec,
    SlidingWindowSpec,
)
from vllm.v1.kv_offload.base import (
    GPULoadStoreSpec,
    OffloadingManager,
    OffloadingSpec,
    OffloadKey,
    OffloadPolicy,
    ReqContext,
    RequestOffloadingContext,
    get_offload_block_hash,
    get_offload_group_idx,
    make_offload_key,
)
from vllm.v1.core.kv_cache_utils import make_block_hash_with_group_id
from vllm.v1.kv_offload.cpu.manager import CPUOffloadingManager
from vllm.v1.outputs import KVConnectorOutput
from vllm.v1.request import Request

logger = init_logger(__name__)


def _count_contiguous_ready_prefix(
    local_ready: Sequence[bool], external_ready: Sequence[bool]
) -> tuple[int, int]:
    """Return contiguous ready blocks and external-only blocks in that prefix."""
    if len(local_ready) != len(external_ready):
        raise ValueError("local and external readiness vectors must have equal length")
    covered = 0
    external_needed = 0
    for is_local, is_external_ready in zip(local_ready, external_ready):
        if not (is_local or is_external_ready):
            break
        covered += 1
        if is_external_ready and not is_local:
            external_needed += 1
    return covered, external_needed


@dataclass(slots=True)
class TransferJobStatus:
    """Tracks scheduler-side state for a single transfer job."""

    req_id: ReqId
    # Number of workers still pending. Starts at num_workers,
    # decremented as each worker reports completion. Job is done at 0.
    pending_count: int
    # Offload keys this job covers; passed to manager.complete_*().
    keys: set[OffloadKey]
    is_store: bool
    # Store src block IDs whose ref_cnt protects them while the request
    # runs. Only registered in _block_id_to_pending_jobs on request_finished.
    non_sliding_window_block_ids: list[int] | None = None
    # Store src block IDs that may be freed before the request finishes.
    # Registered in _block_id_to_pending_jobs at store creation time.
    sliding_window_block_ids: list[int] | None = None
    slackkv_transfer_time_s: float = 0.0
    slackkv_transfer_bytes: int = 0


class GroupOffloadConfig(NamedTuple):
    group_idx: int
    gpu_block_size: int
    offloaded_block_size: int
    hash_block_size_factor: int
    # None below means full attention
    sliding_window_size_in_blocks: int | None
    # Number of this group's offloaded blocks per full-attention alignment
    # segment. Used to skip storing SWA blocks that can never serve a load
    # hit (e.g. DeepSeek V4 where SWA groups have much smaller block sizes
    # than the MLA full-attention group).
    # None for full-attention groups or when the optimization doesn't apply.
    alignment_block_count: int | None = None


def get_sliding_window_size_in_blocks(
    kv_cache_spec: KVCacheSpec, offloaded_block_size: int
) -> int | None:
    if isinstance(kv_cache_spec, SlidingWindowSpec):
        assert kv_cache_spec.sliding_window > 0
        return cdiv(kv_cache_spec.sliding_window, offloaded_block_size)

    if isinstance(kv_cache_spec, MambaSpec):
        # Mamba depends on a single state
        return 1

    assert isinstance(kv_cache_spec, FullAttentionSpec)
    return None


class SchedulerOffloadConfig(NamedTuple):
    kv_group_configs: tuple[GroupOffloadConfig, ...]
    block_size_factor: int
    num_workers: int
    offload_prompt_only: bool

    @classmethod
    def from_spec(cls, spec: OffloadingSpec) -> "SchedulerOffloadConfig":
        # Determine the alignment token count from the full-attention group(s).
        # This is the offloaded_block_size of the full-attention group; load
        # hits are always aligned to this boundary, so SWA blocks earlier in
        # each segment can never serve a load hit. Relevant for hybrid
        # architectures like DeepSeek V4 (MLA + SWA groups).
        full_attn_offloaded_block_sizes: set[int] = set()
        for idx, gpu_block_size in enumerate(spec.gpu_block_size):
            kv_spec = spec.kv_cache_config.kv_cache_groups[idx].kv_cache_spec
            sw = get_sliding_window_size_in_blocks(
                kv_spec, gpu_block_size * spec.block_size_factor
            )
            if sw is None:
                full_attn_offloaded_block_sizes.add(
                    gpu_block_size * spec.block_size_factor
                )

        # Only apply the optimization if there's a single consistent
        # full-attention alignment size.
        alignment_tokens: int | None = None
        if len(full_attn_offloaded_block_sizes) == 1:
            alignment_tokens = full_attn_offloaded_block_sizes.pop()

        def _alignment_block_count(
            offloaded_block_size: int,
            sliding_window_size_in_blocks: int | None,
        ) -> int | None:
            if alignment_tokens is None or sliding_window_size_in_blocks is None:
                return None
            if alignment_tokens <= offloaded_block_size:
                return None
            per_segment = alignment_tokens // offloaded_block_size
            if sliding_window_size_in_blocks >= per_segment:
                return None
            return per_segment

        return cls(
            num_workers=spec.vllm_config.parallel_config.world_size,
            kv_group_configs=tuple(
                GroupOffloadConfig(
                    group_idx=idx,
                    gpu_block_size=gpu_block_size,
                    offloaded_block_size=gpu_block_size * spec.block_size_factor,
                    hash_block_size_factor=(
                        (gpu_block_size * spec.block_size_factor)
                        // spec.hash_block_size
                    ),
                    sliding_window_size_in_blocks=(
                        sw := get_sliding_window_size_in_blocks(
                            spec.kv_cache_config.kv_cache_groups[idx].kv_cache_spec,
                            gpu_block_size * spec.block_size_factor,
                        )
                    ),
                    alignment_block_count=_alignment_block_count(
                        gpu_block_size * spec.block_size_factor, sw
                    ),
                )
                for idx, gpu_block_size in enumerate(spec.gpu_block_size)
            ),
            block_size_factor=spec.block_size_factor,
            offload_prompt_only=spec.offload_prompt_only,
        )


@dataclass
class RequestGroupState:
    offload_keys: list[OffloadKey] = field(default_factory=list)
    block_ids: list[int] = field(default_factory=list)
    # index of next block (of size offloaded_block_size) to offload
    next_stored_block_idx: int = 0
    # number of offloaded blocks hit (including GPU prefix cache)
    # when the request first started
    num_hit_blocks: int = 0


@dataclass(slots=True)
class RequestOffloadState:
    config: SchedulerOffloadConfig
    req: Request
    req_context: ReqContext
    offloading_context: RequestOffloadingContext
    group_states: tuple[RequestGroupState, ...] = field(init=False)
    # upper bound on tokens to offload for this request; None means no cap
    max_offload_tokens: int | None = None
    # number of hits in the GPU cache
    num_locally_computed_tokens: int = 0
    # In-flight job IDs. Per the connector's invariant, at any given time
    # this contains either a single load job, or one or more store jobs.
    transfer_jobs: set[int] = field(default_factory=set)
    slackkv_external_tokens_loaded: int = 0
    slackkv_cpu_to_gpu_transfer_s: float = 0.0
    slackkv_transfer_bytes: int = 0

    def __post_init__(self) -> None:
        self.group_states = tuple(
            RequestGroupState() for _ in self.config.kv_group_configs
        )
        params = self.req.kv_transfer_params

        # NOTE: This field is experimental and subject to change in the future.
        raw = params.get("max_offload_tokens") if params else None
        if type(raw) is int and raw >= 0:
            self.max_offload_tokens = raw
            logger.debug(
                "Request %s: max_offload_tokens set to %d",
                self.req.request_id,
                raw,
            )
        elif raw is not None:
            logger.warning(
                "max_offload_tokens must be a non-negative int, got %r; ignoring", raw
            )

    def update_offload_keys(self) -> None:
        for group_config, group_state in zip(
            self.config.kv_group_configs, self.group_states
        ):
            for req_block_hash in islice(
                self.req.block_hashes,
                group_config.hash_block_size_factor * len(group_state.offload_keys)
                + group_config.hash_block_size_factor
                - 1,
                None,
                group_config.hash_block_size_factor,
            ):
                group_state.offload_keys.append(
                    make_offload_key(req_block_hash, group_config.group_idx)
                )

    def update_block_id_groups(
        self, new_block_id_groups: tuple[list[int], ...] | None
    ) -> None:
        if new_block_id_groups is None:
            return

        assert len(new_block_id_groups) == len(self.group_states)
        for group_state, new_blocks in zip(self.group_states, new_block_id_groups):
            group_state.block_ids.extend(new_blocks)

    def advance_stored_idx(self, num_offloadable_tokens: int) -> None:
        for group_config, group_state in zip(
            self.config.kv_group_configs, self.group_states
        ):
            num_blocks = num_offloadable_tokens // group_config.offloaded_block_size
            group_state.next_stored_block_idx = num_blocks

    def update_num_hit_blocks(self, num_cached_tokens: int) -> None:
        for group_config, group_state in zip(
            self.config.kv_group_configs, self.group_states
        ):
            group_state.num_hit_blocks = (
                num_cached_tokens // group_config.offloaded_block_size
            )


def _create_req_context(req: Request) -> ReqContext:
    return ReqContext(
        req_id=req.request_id,
        kv_transfer_params=req.kv_transfer_params,
    )


class OffloadingConnectorScheduler:
    """Implementation of Scheduler side methods"""

    def __init__(self, spec: OffloadingSpec):
        self.config = SchedulerOffloadConfig.from_spec(spec)
        self.manager: OffloadingManager = spec.get_manager()

        full_attention_groups: list[int] = []
        sliding_window_groups: list[int] = []
        for group_config in self.config.kv_group_configs:
            if group_config.sliding_window_size_in_blocks is None:
                full_attention_groups.append(group_config.group_idx)
            else:
                sliding_window_groups.append(group_config.group_idx)

        # sort sliding window groups by window size in decreasing order
        def _sliding_window_sort_key(i: int) -> int:
            val = self.config.kv_group_configs[i].sliding_window_size_in_blocks
            assert val is not None
            return val

        sliding_window_groups.sort(key=_sliding_window_sort_key, reverse=True)

        # used by _lookup
        self._sliding_window_groups: tuple[int, ...] = tuple(sliding_window_groups)
        self._lookup_groups = tuple(full_attention_groups) + self._sliding_window_groups

        self._req_status: dict[ReqId, RequestOffloadState] = {}
        self._current_batch_load_jobs: dict[int, TransferJob] = {}
        self._current_batch_jobs_to_flush: set[int] = set()
        # GPU block IDs allocated in the current engine step
        self._current_batch_allocated_block_ids: set[int] = set()
        # if GPU prefix caching is enabled,
        # track loaded blocks to avoid redundant loads
        self._blocks_being_loaded: set[OffloadKey] | None = (
            set() if spec.vllm_config.cache_config.enable_prefix_caching else None
        )

        # Job ID counter shared by loads and stores.
        self._job_counter: int = 0
        # Threshold value for stale jobs. All job ids >= _stale_job_threshold are
        # active jobs.
        self._stale_job_threshold: int = 0
        self._jobs: dict[int, TransferJobStatus] = {}

        # block_id -> pending store job_ids. Used to track jobs that needs
        # flushing in case a block is re-allocated by the KV cache manager.
        # Populated only for finished requests (running-request blocks are
        # protected by their ref_cnt) and for sliding window blocks (which can
        # be freed before a request finishes).
        self._block_id_to_pending_jobs: dict[int, set[int]] = {}
        self._slackkv_source_ready_emitted: set[str] = set()
        self._slackkv_probe_gpu_pool = None
        self._slackkv_probe_boundaries: dict[str, dict[str, Any]] = {}
        self._slackkv_probe_interval_ns = 20_000_000
        self._slackkv_probe_next_ns = 0
        self._slackkv_probe_sample_id = 0
        self._slackkv_probe_error_emitted = False

    def bind_gpu_block_pool(self, gpu_block_pool: Any) -> None:
        self._slackkv_probe_gpu_pool = gpu_block_pool

    def slackkv_probe_delay_s(self, now_ns: int | None = None) -> float | None:
        if not any(row.get("resume_issue_ns") is None for row in self._slackkv_probe_boundaries.values()):
            return None
        now = time.monotonic_ns() if now_ns is None else now_ns
        return max(0.001, (self._slackkv_probe_next_ns - now) / 1e9)

    def slackkv_probe_due(self, now_ns: int | None = None) -> bool:
        if not any(row.get("resume_issue_ns") is None for row in self._slackkv_probe_boundaries.values()):
            return False
        now = time.monotonic_ns() if now_ns is None else now_ns
        return now >= self._slackkv_probe_next_ns

    def slackkv_exact_source_state(self, boundary_id: str) -> dict[str, Any]:
        """Read one registered boundary directly from the exact CPU/GPU indexes."""
        started_ns = time.thread_time_ns()
        boundary = self._slackkv_probe_boundaries.get(boundary_id)
        pool = self._slackkv_probe_gpu_pool
        if (boundary is None or pool is None or not isinstance(self.manager, CPUOffloadingManager)
                or self.manager.counts is not None or not hasattr(self.manager._policy, "get")):
            return {"available": False, "boundary_id": boundary_id,
                    "reason": "EXACT_READ_ONLY_SOURCE_API_UNAVAILABLE"}
        local_ids: set[int] = set()
        local_ref_counts: dict[int, int] = {}
        local_prefix: list[Any] = []
        local_prefix_by_group: dict[int, list[Any]] = {}
        local_flags: list[bool] = []
        external_flags: list[bool] = []
        external_ready = 0
        prefix_open = True
        block_map = pool.cached_block_hash_to_block
        for key in boundary["keys"]:
            group_id = get_offload_group_idx(key)
            block_hash = get_offload_block_hash(key)
            cached = block_map.get_one_block(make_block_hash_with_group_id(block_hash, group_id))
            is_local = cached is not None and not cached.is_null
            if is_local:
                local_ids.add(int(cached.block_id))
                local_ref_counts[int(cached.block_id)] = int(cached.ref_cnt)
                if prefix_open:
                    local_prefix.append(cached)
                    local_prefix_by_group.setdefault(group_id, []).append(cached)
            else:
                prefix_open = False
            status = self.manager._policy.get(key)
            is_external_ready = status is not None and status.is_ready
            local_flags.append(is_local)
            external_flags.append(is_external_ready)
            if is_external_ready:
                external_ready += 1
        required = int(boundary["required_blocks"])
        covered, external_ready_needed = _count_contiguous_ready_prefix(
            local_flags, external_flags
        )
        covered = min(required, covered)
        return {
            "available": True, "boundary_id": boundary_id,
            "timestamp_monotonic_ns": time.monotonic_ns(),
            "required_blocks": required,
            "local_cached_blocks": len(local_ids),
            "local_prefix_blocks": len(local_prefix),
            "external_ready_blocks": external_ready,
            "external_ready_needed_blocks": min(external_ready_needed, max(0, required - len(local_ids))),
            "covered_blocks": covered, "source_fully_ready": covered >= required,
            "local_block_ids": sorted(local_ids),
            "local_block_ref_counts": local_ref_counts,
            "local_prefix_block_ids": [int(block.block_id) for block in local_prefix],
            "local_prefix_blocks_by_group": {
                str(group_id): [int(block.block_id) for block in blocks]
                for group_id, blocks in local_prefix_by_group.items()
            },
            "read_cpu_ns": max(0, time.thread_time_ns() - started_ns),
            "_local_prefix_block_objects": local_prefix,
            "_local_prefix_blocks_by_group": local_prefix_by_group,
        }

    def slackkv_probe_source_readiness(self, snapshot: dict[str, Any]) -> None:
        now_ns = int(snapshot["probe_start_ns"])
        if now_ns < self._slackkv_probe_next_ns:
            return
        if not any(row.get("resume_issue_ns") is None for row in self._slackkv_probe_boundaries.values()):
            return
        self._slackkv_probe_next_ns = now_ns + self._slackkv_probe_interval_ns
        pool = self._slackkv_probe_gpu_pool
        if pool is None or not isinstance(self.manager, CPUOffloadingManager):
            if not self._slackkv_probe_error_emitted:
                logger.error("SLACKKV_READY_PROBE %s", json.dumps({
                    "event": "PROBE_ERROR", "timestamp_monotonic_ns": now_ns,
                    "reason": "EXACT_READ_ONLY_SOURCE_API_UNAVAILABLE",
                    "manager_type": type(self.manager).__name__,
                    "gpu_block_pool_bound": pool is not None,
                }, separators=(",", ":")))
                self._slackkv_probe_error_emitted = True
            return
        if self.manager.counts is not None or not hasattr(self.manager._policy, "get"):
            if not self._slackkv_probe_error_emitted:
                logger.error("SLACKKV_READY_PROBE %s", json.dumps({
                    "event": "PROBE_ERROR", "timestamp_monotonic_ns": now_ns,
                    "reason": "SOURCE_PROBE_NOT_READ_ONLY_FOR_CONFIGURED_MANAGER",
                }, separators=(",", ":")))
                self._slackkv_probe_error_emitted = True
            return

        probe_id = self._slackkv_probe_sample_id
        self._slackkv_probe_sample_id += 1
        probe_cpu_start_ns = time.thread_time_ns()
        cpu_policy = self.manager._policy
        block_map = pool.cached_block_hash_to_block
        total_blocks = int(pool.num_gpu_blocks)
        free_blocks = int(pool.get_num_free_blocks())
        leases = snapshot["leases"]
        lease_block_ids = sorted({
            int(block_id)
            for block_ids in leases.values()
            for block_id in block_ids
        })
        sample_rows: list[dict[str, Any]] = []
        pending_frontier = [
            (key, row) for key, row in self._slackkv_probe_boundaries.items()
            if row.get("resume_request_id") is None
            or row.get("resume_request_id") not in set(snapshot["first_token_request_ids"])
        ]
        protected_id, protected_state = (
            min(pending_frontier, key=lambda item: (int(item[1]["estimated_deadline_ns"]), item[0]))
            if pending_frontier else (None, None)
        )
        for boundary_id, boundary in list(self._slackkv_probe_boundaries.items()):
            if boundary.get("resume_issue_ns") is not None:
                continue
            keys = boundary["keys"]
            local_ids: list[int] = []
            local_flags: list[bool] = []
            external_flags: list[bool] = []
            external_ready = 0
            for key in keys:
                group_id = get_offload_group_idx(key)
                block_hash = get_offload_block_hash(key)
                cached = block_map.get_one_block(make_block_hash_with_group_id(block_hash, group_id))
                if cached is not None and not cached.is_null:
                    local_ids.append(int(cached.block_id))
                    local_flags.append(True)
                else:
                    local_flags.append(False)
                status = cpu_policy.get(key)
                is_external_ready = status is not None and status.is_ready
                external_flags.append(is_external_ready)
                if is_external_ready:
                    external_ready += 1
            required = int(boundary["required_blocks"])
            local_unique = len(set(local_ids))
            covered, external_ready_needed = _count_contiguous_ready_prefix(
                local_flags, external_flags
            )
            covered = min(required, covered)
            missing = max(0, required - covered)
            external_needed = max(0, required - local_unique)
            sample_rows.append({
                "event": "SAMPLE", "sample_id": probe_id,
                "timestamp_monotonic_ns": now_ns,
                "boundary_id": boundary_id, "session": boundary["session"],
                "request_id": boundary["request_id"],
                "required_blocks": required,
                "required_tokens": boundary["required_tokens"],
                "local_cached_blocks": local_unique,
                "external_ready_blocks": external_ready,
                "external_ready_needed_blocks": min(external_ready_needed, external_needed),
                "covered_blocks": covered, "missing_blocks": missing,
                "source_fully_ready": covered == required,
                "free_blocks": free_blocks, "total_blocks": total_blocks,
                "used_blocks": total_blocks - free_blocks,
                "num_running": snapshot["num_running"],
                "num_waiting": snapshot["num_waiting"],
                "running_unique_blocks": snapshot["running_unique_blocks"],
                "waiting_unique_blocks": snapshot["waiting_unique_blocks"],
                "active_lease_count": len(leases),
                "active_lease_unique_blocks": len(lease_block_ids),
                "lease_key": boundary["lease_key"],
                "protected_frontier": protected_id,
                "protected_progress_blocks": (
                    int(protected_state["protected_progress_blocks"])
                    if protected_state is not None else 0
                ),
                "protected_lease_blocks": (
                    len(set(leases.get(protected_state["lease_key"], [])))
                    if protected_state is not None else 0
                ),
                "estimated_deadline_ns": boundary["estimated_deadline_ns"],
                "resume_issue_ns": boundary.get("resume_issue_ns"),
            })
        for row in sample_rows:
            logger.info("SLACKKV_READY_PROBE %s", json.dumps(row, separators=(",", ":")))
        probe_wall_duration_ns = max(0, time.monotonic_ns() - now_ns)
        probe_cpu_duration_ns = max(0, time.thread_time_ns() - probe_cpu_start_ns)
        logger.info("SLACKKV_READY_PROBE %s", json.dumps({
            "event": "PROBE_COST", "sample_id": probe_id,
            "timestamp_monotonic_ns": now_ns,
            "probe_duration_ns": probe_cpu_duration_ns,
            "probe_wall_duration_ns": probe_wall_duration_ns,
            "probe_boundary_count": len(sample_rows),
            "probe_interval_ns": self._slackkv_probe_interval_ns,
        }, separators=(",", ":")))

    def _slackkv_trace_source_readiness(self, req_status: RequestOffloadState) -> None:
        """Observe a traced next-turn prefix without changing offload policy."""
        params = req_status.req.kv_transfer_params or {}
        boundary_id = params.get("slackkv_trace_next_boundary")
        required = params.get("slackkv_trace_source_required_tokens")
        if not isinstance(boundary_id, str) or type(required) is not int:
            return
        if boundary_id in self._slackkv_source_ready_emitted:
            return
        if required <= 0 or required % 16 or len(req_status.group_states) != 1:
            return
        group = req_status.group_states[0]
        block_size = self.config.kv_group_configs[0].offloaded_block_size
        if block_size != 16:
            return
        required_blocks = required // block_size
        available_keys = group.offload_keys[:required_blocks]
        if (
            type(params.get("slackkv_trace_next_isl")) is int
            and type(params.get("slackkv_trace_next_pause_ms")) in (int, float)
        ):
            registered_ns = time.monotonic_ns()
            self._slackkv_probe_boundaries[boundary_id] = {
                "request_id": req_status.req.request_id,
                "session": params.get("slackkv_session"),
                "keys": tuple(available_keys),
                "required_tokens": required,
                "required_blocks": required_blocks,
                "available_key_blocks": len(available_keys),
                "pause_ms": float(params["slackkv_trace_next_pause_ms"]),
                "lease_key": params.get("slackkv_trace_next_lease_key"),
                "estimated_deadline_ns": registered_ns + round(float(params["slackkv_trace_next_pause_ms"]) * 1e6),
                "protected_progress_blocks": (int(params["slackkv_trace_next_isl"]) + 1 + 15) // 16,
                "resume_issue_ns": None,
            }
            self._slackkv_probe_next_ns = min(self._slackkv_probe_next_ns or registered_ns, registered_ns)
        ready_blocks = 0
        for key in available_keys:
            if self.manager.lookup(key, req_status.req_context) is not True:
                break
            ready_blocks += 1
        ready = len(available_keys) == required_blocks and ready_blocks == required_blocks
        logger.info(
            "SLACKKV_OFFLOAD_TRACE %s",
            json.dumps({
                "event": "SOURCE_READY" if ready else "SOURCE_NOT_READY",
                "timestamp_monotonic": time.monotonic(),
                "boundary_id": boundary_id,
                "request_id": req_status.req.request_id,
                "session": params.get("slackkv_session"),
                "required_tokens": required,
                "required_blocks": required_blocks,
                "available_hash_blocks": len(available_keys),
                "ready_prefix_blocks": ready_blocks,
            }, separators=(",", ":")),
        )
        if ready:
            self._slackkv_source_ready_emitted.add(boundary_id)

    def _generate_job_id(self) -> int:
        job_id = self._job_counter
        self._job_counter += 1
        return job_id

    def _remove_pending_job(self, job_id: int, block_ids: list[int] | None) -> None:
        for bid in block_ids or ():
            pending = self._block_id_to_pending_jobs[bid]
            pending.remove(job_id)
            if not pending:
                del self._block_id_to_pending_jobs[bid]

    def _maximal_prefix_lookup(
        self, keys: Iterable[OffloadKey], req_context: ReqContext
    ) -> int | None:
        """Return the number of consecutive offloaded blocks from the start,
        or None if the backend deferred a lookup."""
        hit_count = 0
        defer_lookup = False
        for key in keys:
            result = self.manager.lookup(key, req_context)
            if result is None:
                defer_lookup = True
                # continue lookup to allow manager to kick-off async lookups
                # for all blocks (until a miss is detected)
                result = True
            if not result:
                break
            hit_count += 1
        return hit_count if not defer_lookup else None

    def _sliding_window_lookup(
        self,
        keys: Sequence[OffloadKey],
        sliding_window_size: int,
        req_context: ReqContext,
    ) -> int | None:
        """Return the end index (in `keys`) of the last run of
        `sliding_window_size` consecutive hits, scanning from the end.
        Returns 0 on miss, None if the backend deferred a lookup."""
        defer_lookup = False
        consecutive_hits = 0
        for idx in range(len(keys) - 1, -1, -1):
            result = self.manager.lookup(keys[idx], req_context)
            if result is None:
                defer_lookup = True
                # continue lookup to allow manager to kick-off async lookups
                # for all blocks (until a hit is detected)
                result = False
            if not result:
                consecutive_hits = 0
            else:
                consecutive_hits += 1
                if consecutive_hits == sliding_window_size:
                    return idx + sliding_window_size if not defer_lookup else None
        return consecutive_hits if not defer_lookup else None

    def _touch(self, req_status: RequestOffloadState):
        for group_config, group_state in zip(
            self.config.kv_group_configs, req_status.group_states
        ):
            if group_config.sliding_window_size_in_blocks is None:
                self.manager.touch(group_state.offload_keys, req_status.req_context)
            else:
                # we aim to keep just blocks that are necessary to hit
                # the original request (+ decoded blocks)
                blocks_to_skip = max(
                    0,
                    group_state.num_hit_blocks
                    - group_config.sliding_window_size_in_blocks,
                )
                self.manager.touch(
                    group_state.offload_keys[blocks_to_skip:],
                    req_status.req_context,
                )

    def _lookup(self, req_status: RequestOffloadState) -> int | None:
        """
        Find how many tokens beyond num_locally_computed_tokens can be loaded.

        Iterates full-attention groups first (prefix lookup), then sliding-window
        groups (suffix lookup). Each group may tighten max_hit_size_tokens, which
        can invalidate an earlier group's result, so the loop re-runs when that
        happens until num_hit_tokens converges.
        """
        num_computed_tokens = req_status.num_locally_computed_tokens
        max_hit_size_tokens: int = req_status.req.num_tokens
        if self._sliding_window_groups:
            # the last prompt token has to be recomputed to get the logprobs
            # for sliding window attention, we must reduce by 1 to make sure
            # we still have a hit after reduction
            max_hit_size_tokens -= 1
        num_hit_tokens: int = 0
        defer_lookup = False
        lookup_groups = self._lookup_groups
        while lookup_groups:
            looked_up_sliding_window: bool = False
            groups_iter = iter(lookup_groups)
            lookup_groups = ()
            for group_idx in groups_iter:
                group_config: GroupOffloadConfig = self.config.kv_group_configs[
                    group_idx
                ]
                group_state: RequestGroupState = req_status.group_states[group_idx]
                offloaded_block_size = group_config.offloaded_block_size
                offload_keys = group_state.offload_keys

                assert (
                    len(offload_keys)
                    >= req_status.req.num_tokens // offloaded_block_size
                )

                # Constrain to block-aligned boundary for this group
                max_hit_size_tokens = min(
                    max_hit_size_tokens, len(offload_keys) * offloaded_block_size
                )
                if max_hit_size_tokens - num_computed_tokens < offloaded_block_size:
                    # we can only load less than a block, better skip
                    return 0

                num_blocks = min(
                    cdiv(max_hit_size_tokens, offloaded_block_size), len(offload_keys)
                )
                start_block_idx = num_computed_tokens // offloaded_block_size
                offload_keys = offload_keys[start_block_idx:num_blocks]
                sliding_window_size_in_blocks = (
                    group_config.sliding_window_size_in_blocks
                )

                # end index (in the sliced offload_keys) up to which we
                # have backend-confirmed hits
                num_hit_blocks: int | None
                if sliding_window_size_in_blocks is None:
                    num_hit_blocks = self._maximal_prefix_lookup(
                        offload_keys, req_status.req_context
                    )
                else:
                    num_hit_blocks = self._sliding_window_lookup(
                        offload_keys,
                        sliding_window_size_in_blocks,
                        req_status.req_context,
                    )
                if num_hit_blocks == 0:
                    return 0

                if num_hit_blocks is None:
                    defer_lookup = True
                else:
                    max_hit_size_tokens = min(
                        max_hit_size_tokens,
                        offloaded_block_size * (start_block_idx + num_hit_blocks),
                    )

                new_num_hit_tokens = max_hit_size_tokens - num_computed_tokens
                if new_num_hit_tokens < offloaded_block_size:
                    # we can only load less than a block, better skip
                    return 0

                if new_num_hit_tokens < num_hit_tokens:
                    if defer_lookup:
                        # make another iteration on all groups to check
                        # if we still need to defer lookup
                        defer_lookup = False
                        lookup_groups = self._lookup_groups
                    elif looked_up_sliding_window and not lookup_groups:
                        # we need another iteration to confirm previously looked up
                        # sliding window works with the new_num_hit_tokens
                        lookup_groups = self._sliding_window_groups

                looked_up_sliding_window |= sliding_window_size_in_blocks is not None
                num_hit_tokens = new_num_hit_tokens

        if defer_lookup:
            logger.debug(
                "Offloading manager delayed request %s as backend requested",
                req_status.req.request_id,
            )
            return None

        # possibly delay request if any of the hit blocks is already being loaded
        if self._blocks_being_loaded:
            for group_config, group_state in zip(
                self.config.kv_group_configs, req_status.group_states
            ):
                offloaded_block_size = group_config.offloaded_block_size
                sliding_window_size_in_blocks = (
                    group_config.sliding_window_size_in_blocks
                )
                offload_keys = group_state.offload_keys
                num_blocks = cdiv(
                    num_computed_tokens + num_hit_tokens, offloaded_block_size
                )
                start_block_idx = num_computed_tokens // offloaded_block_size
                offload_keys = offload_keys[start_block_idx:num_blocks]
                if sliding_window_size_in_blocks is not None:
                    offload_keys = offload_keys[-sliding_window_size_in_blocks:]
                if any(key in self._blocks_being_loaded for key in offload_keys):
                    # hit blocks are being loaded, delay request
                    logger.debug(
                        "Delaying request %s since some of its"
                        " blocks are already being loaded",
                        req_status.req.request_id,
                    )
                    return None

        logger.debug(
            "Request %s hit %s offloaded tokens after %s GPU hit tokens",
            req_status.req.request_id,
            num_hit_tokens,
            num_computed_tokens,
        )

        return num_hit_tokens

    def on_new_request(self, request: Request) -> None:
        """Called when a new request is added to the scheduler."""
        req_context = _create_req_context(request)
        offloading_context = self.manager.on_new_request(req_context)
        req_status = RequestOffloadState(
            config=self.config,
            req=request,
            req_context=req_context,
            offloading_context=offloading_context,
        )
        self._req_status[request.request_id] = req_status
        params = request.kv_transfer_params or {}
        boundary_id = params.get("slackkv_trace_boundary_id")
        issue_ns = params.get("slackkv_trace_resume_issue_ns")
        if isinstance(boundary_id, str) and type(issue_ns) is int:
            boundary = self._slackkv_probe_boundaries.get(boundary_id)
            if boundary is not None:
                boundary["resume_issue_ns"] = issue_ns
                boundary["resume_request_id"] = request.request_id

    def get_num_new_matched_tokens(
        self, request: Request, num_computed_tokens: int
    ) -> tuple[int | None, bool]:
        """
        Get number of new tokens that can be loaded beyond the
        num_computed_tokens.

        Args:
            request (Request): the request object.
            num_computed_tokens (int): the number of locally
                computed tokens for this request

        Returns:
            A tuple with the following elements:
                - The number of tokens that can be loaded beyond what is
                  already computed.
                  If None, it means that the connector needs more time to
                  determine the number of matched tokens, and the scheduler
                  should query for this request again later.
                - `True` if tokens will be loaded asynchronously
                  (between scheduler steps).
        """
        req_status = self._req_status[request.request_id]
        for group_state in req_status.group_states:
            group_state.block_ids.clear()

        req_status.update_offload_keys()
        req_status.num_locally_computed_tokens = num_computed_tokens

        num_hit_tokens = self._lookup(req_status)
        req_status.update_num_hit_blocks(num_computed_tokens + (num_hit_tokens or 0))

        self._touch(req_status)

        return num_hit_tokens, bool(num_hit_tokens)

    def update_state_after_alloc(
        self, request: Request, blocks: KVCacheBlocks, num_external_tokens: int
    ):
        if num_external_tokens == 0:
            return

        req_status = self._req_status[request.request_id]
        req_status.slackkv_external_tokens_loaded = num_external_tokens

        num_locally_computed_tokens = req_status.num_locally_computed_tokens
        num_cached_tokens = num_locally_computed_tokens + num_external_tokens

        keys_to_load: list[OffloadKey] = []
        dst_block_ids: list[int] = []
        # per group
        group_sizes: list[int] = []
        block_indices: list[int] = []
        for group_config, group_state, group_blocks in zip(
            self.config.kv_group_configs,
            req_status.group_states,
            blocks.blocks,
        ):
            self._current_batch_allocated_block_ids.update(
                block.block_id for block in group_blocks if block.block_id != 0
            )

            gpu_block_size = group_config.gpu_block_size
            offloaded_block_size = group_config.offloaded_block_size
            offload_keys = group_state.offload_keys
            num_gpu_blocks = cdiv(num_cached_tokens, gpu_block_size)

            assert len(group_blocks) >= num_gpu_blocks
            num_locally_computed_gpu_blocks = num_gpu_blocks
            # Skip null placeholder blocks (used for sliding window or mamba padding).
            for i, block in enumerate(group_blocks[:num_gpu_blocks]):
                if not block.is_null and block.block_hash is None:
                    num_locally_computed_gpu_blocks = i
                    break

            assert (
                num_locally_computed_tokens
                <= num_locally_computed_gpu_blocks * gpu_block_size
            )
            num_pending_gpu_blocks = num_gpu_blocks - num_locally_computed_gpu_blocks

            if group_config.sliding_window_size_in_blocks is not None:
                assert (
                    num_pending_gpu_blocks
                    <= group_config.sliding_window_size_in_blocks
                    * self.config.block_size_factor
                )

            num_blocks = cdiv(num_cached_tokens, offloaded_block_size)
            assert len(offload_keys) >= num_blocks
            if num_pending_gpu_blocks:
                start_block_idx = (
                    num_locally_computed_gpu_blocks // self.config.block_size_factor
                )
                keys_to_load.extend(offload_keys[start_block_idx:num_blocks])

            dst_block_ids.extend(
                block.block_id
                for block in group_blocks[
                    num_locally_computed_gpu_blocks:num_gpu_blocks
                ]
            )
            group_sizes.append(num_pending_gpu_blocks)
            block_indices.append(num_locally_computed_gpu_blocks)

            # Skip prefix-hit blocks for block-level policy; for
            # request-level, next_stored_block_idx stays at 0 so all
            # blocks (including hits) are offloaded.
            if req_status.offloading_context.policy == OffloadPolicy.BLOCK_LEVEL:
                group_state.next_stored_block_idx = num_blocks

        src_spec = self.manager.prepare_load(keys_to_load, req_status.req_context)
        dst_spec = GPULoadStoreSpec(
            dst_block_ids, group_sizes=group_sizes, block_indices=block_indices
        )

        load_job_id = self._generate_job_id()
        self._current_batch_load_jobs[load_job_id] = TransferJob(
            req_id=request.request_id,
            transfer_spec=(src_spec, dst_spec),
            slackkv_prefetch_only=bool(
                request.kv_transfer_params
                and request.kv_transfer_params.get("slackkv_prefetch_only") is True
            ),
        )
        # a load can only be issued when no other jobs are pending.
        assert not req_status.transfer_jobs
        req_status.transfer_jobs.add(load_job_id)
        self._jobs[load_job_id] = TransferJobStatus(
            req_id=request.request_id,
            pending_count=self.config.num_workers,
            keys=set(keys_to_load),
            is_store=False,
        )

        if self._blocks_being_loaded is not None:
            self._blocks_being_loaded.update(keys_to_load)

    def _update_req_states(self, scheduler_output: SchedulerOutput) -> None:
        """
        Update request states from the Scheduler's output.
        """

        # new_block_ids_end[req_id][i] = end of pre-existing block_ids for
        # the i-th sliding window group (before this step's extend).
        # Used to detect sliding window blocks that got re-allocated.
        new_block_ids_end: dict[str, tuple[int, ...]] = {}

        for req_id, new_block_id_groups, preempted in yield_req_data(scheduler_output):
            req_status = self._req_status[req_id]
            req_status.update_offload_keys()

            if preempted:
                for group_state in req_status.group_states:
                    group_state.block_ids.clear()

            if new_block_id_groups:
                if self._sliding_window_groups:
                    new_block_ids_end[req_id] = tuple(
                        len(req_status.group_states[grp_idx].block_ids)
                        for grp_idx in self._sliding_window_groups
                    )
                req_status.update_block_id_groups(new_block_id_groups)
                for new_blocks in new_block_id_groups:
                    for bid in new_blocks:
                        if bid != 0:
                            self._current_batch_allocated_block_ids.add(bid)

        # Zero out stale block_ids in sliding window groups' pending-store
        # positions. Only sliding window groups can have stale entries (blocks
        # freed by remove_skipped_blocks then reallocated). Only positions in
        # [next_stored_block_idx * bsf, end) need checking where end is the
        # pre-extend length: earlier positions were already offloaded, later
        # ones are fresh allocations from this step.
        if self._sliding_window_groups and self._current_batch_allocated_block_ids:
            block_size_factor = self.config.block_size_factor
            for req_id, req_status in self._req_status.items():
                ends = new_block_ids_end.get(req_id)
                for i, grp_idx in enumerate(self._sliding_window_groups):
                    group_state = req_status.group_states[grp_idx]
                    start = group_state.next_stored_block_idx * block_size_factor
                    end = ends[i] if ends is not None else len(group_state.block_ids)
                    for j in range(start, end):
                        if (
                            group_state.block_ids[j]
                            in self._current_batch_allocated_block_ids
                        ):
                            group_state.block_ids[j] = 0

    def _build_store_jobs(
        self,
        scheduler_output: SchedulerOutput,
    ) -> dict[int, TransferJob]:
        block_size_factor = self.config.block_size_factor
        store_jobs: dict[int, TransferJob] = {}
        for req_id in scheduler_output.num_scheduled_tokens:
            req_status = self._req_status.get(req_id)
            if req_status is None:
                continue
            req = req_status.req

            num_scheduled_tokens = scheduler_output.num_scheduled_tokens[req_id]
            num_tokens_after_batch = req.num_computed_tokens + num_scheduled_tokens
            # with async scheduling, some tokens may be missing
            num_offloadable_tokens = min(num_tokens_after_batch, req.num_tokens)
            max_offload_tokens = req_status.max_offload_tokens
            if max_offload_tokens is not None:
                num_offloadable_tokens = min(num_offloadable_tokens, max_offload_tokens)

            # Skip decode-phase blocks: clamp to the prompt length so only
            # prefill (prompt) blocks become eligible for store. next_stored_idx
            # never advances past this boundary, so decode blocks are never
            # queued in this or any later step.
            if self.config.offload_prompt_only:
                num_offloadable_tokens = min(
                    num_offloadable_tokens, req.num_prompt_tokens
                )

            # Filter out blocks skipped due to sliding window attention / SSM
            # or unreachable by the load path's alignment constraints.
            new_offload_keys: list[OffloadKey] = []
            for group_config, group_state in zip(
                self.config.kv_group_configs, req_status.group_states
            ):
                num_blocks = num_offloadable_tokens // group_config.offloaded_block_size
                start_block_idx = group_state.next_stored_block_idx
                if num_blocks <= start_block_idx:
                    continue
                offload_keys = group_state.offload_keys[start_block_idx:num_blocks]
                # For each block to offload, take the last corresponding GPU block.
                # e.g. if block size factor is 3 and GPU block IDs are
                # 1 5 6 7 2 4 9 3 8 then we'll take blocks 6 4 8.
                # A block_id of 0 means either a sliding window / SSM skip
                # or a stale entry that was zeroed out — skip it either way.
                offload_block_ids = group_state.block_ids[
                    start_block_idx * block_size_factor
                    + block_size_factor
                    - 1 : num_blocks * block_size_factor : block_size_factor
                ]
                assert len(offload_keys) == len(offload_block_ids)

                alignment_block_count = group_config.alignment_block_count
                tail = group_config.sliding_window_size_in_blocks

                for key_idx, (offload_key, block_id) in enumerate(
                    zip(offload_keys, offload_block_ids)
                ):
                    if block_id == 0:
                        continue
                    # Skip SWA blocks that can never serve a load hit:
                    # within each full-attention alignment segment, only the
                    # trailing `tail` blocks are reachable by
                    # _sliding_window_lookup. For DeepSeek V4 with 100K
                    # tokens this reduces SWA stores by ~78%.
                    if alignment_block_count is not None:
                        assert tail is not None
                        abs_block_idx = start_block_idx + key_idx
                        pos_in_segment = abs_block_idx % alignment_block_count
                        if pos_in_segment < alignment_block_count - tail:
                            continue
                    new_offload_keys.append(offload_key)

            if not new_offload_keys:
                req_status.advance_stored_idx(num_offloadable_tokens)
                continue

            store_output = self.manager.prepare_store(
                new_offload_keys, req_status.req_context
            )
            if store_output is None:
                logger.warning("Request %s: cannot store blocks", req_id)
                continue

            if not store_output.keys_to_store:
                req_status.advance_stored_idx(num_offloadable_tokens)
                continue

            self._touch(req_status)

            keys_to_store = set(store_output.keys_to_store)

            group_sizes: list[int] = []
            block_indices: list[int] = []
            src_block_ids: list[int] = []
            sliding_window_block_ids: list[int] = []
            non_sliding_window_block_ids: list[int] = []
            for group_config, group_state in zip(
                self.config.kv_group_configs, req_status.group_states
            ):
                is_sliding_window = (
                    group_config.sliding_window_size_in_blocks is not None
                )
                num_blocks = num_offloadable_tokens // group_config.offloaded_block_size
                start_block_idx = group_state.next_stored_block_idx
                block_ids = group_state.block_ids
                num_group_blocks = 0
                start_gpu_block_idx: int | None = None
                for idx, offload_key in enumerate(
                    group_state.offload_keys[start_block_idx:num_blocks]
                ):
                    if offload_key not in keys_to_store:
                        continue

                    offloaded_block_idx = start_block_idx + idx
                    gpu_block_idx = offloaded_block_idx * block_size_factor
                    for i in range(block_size_factor):
                        block_id = block_ids[gpu_block_idx + i]
                        if block_id == 0:
                            continue
                        if start_gpu_block_idx is None:
                            start_gpu_block_idx = gpu_block_idx + i
                        src_block_ids.append(block_id)
                        num_group_blocks += 1
                        if is_sliding_window:
                            sliding_window_block_ids.append(block_id)
                        else:
                            non_sliding_window_block_ids.append(block_id)

                group_sizes.append(num_group_blocks)
                block_indices.append(start_gpu_block_idx or 0)
                group_state.next_stored_block_idx = num_blocks

            src_spec = GPULoadStoreSpec(
                src_block_ids, group_sizes=group_sizes, block_indices=block_indices
            )
            dst_spec = store_output.store_spec

            job_id = self._generate_job_id()
            # a store can only be issued when no load is pending.
            if req_status.transfer_jobs:
                any_jid = next(iter(req_status.transfer_jobs))
                assert self._jobs[any_jid].is_store
            req_status.transfer_jobs.add(job_id)

            # Watch sliding window blocks as they may get evicted
            # before the request finishes
            for bid in sliding_window_block_ids or ():
                self._block_id_to_pending_jobs.setdefault(bid, set()).add(job_id)

            # the non-sliding window blocks will be watched only
            # when the request finishes
            self._jobs[job_id] = TransferJobStatus(
                req_id=req_id,
                pending_count=self.config.num_workers,
                keys=set(keys_to_store),
                is_store=True,
                non_sliding_window_block_ids=non_sliding_window_block_ids,
                sliding_window_block_ids=sliding_window_block_ids or None,
            )

            store_jobs[job_id] = TransferJob(
                req_id=req_id, transfer_spec=(src_spec, dst_spec)
            )

            logger.debug(
                "Request %s offloading %s blocks upto %d tokens (job %d)",
                req_id,
                len(keys_to_store),
                num_offloadable_tokens,
                job_id,
            )

        return store_jobs

    def build_connector_meta(
        self, scheduler_output: SchedulerOutput
    ) -> KVConnectorMetadata:
        self._update_req_states(scheduler_output)
        self.manager.on_schedule_end()

        # Flush jobs for preempted requests.
        for req_id in scheduler_output.preempted_req_ids or ():
            req_status = self._req_status.get(req_id)
            if req_status is None or not req_status.transfer_jobs:
                continue
            any_jid = next(iter(req_status.transfer_jobs))
            assert self._jobs[any_jid].is_store
            self._current_batch_jobs_to_flush.update(req_status.transfer_jobs)

        # Flush jobs that contain re-allocated blocks.
        if (
            self._block_id_to_pending_jobs
            and not self._block_id_to_pending_jobs.keys().isdisjoint(
                self._current_batch_allocated_block_ids
            )
        ):
            self._current_batch_jobs_to_flush.update(
                jid
                for bid in self._current_batch_allocated_block_ids
                if bid in self._block_id_to_pending_jobs
                for jid in self._block_id_to_pending_jobs[bid]
            )

        # If all tracked requests are finished, flush all pending jobs
        # (both store and load) - there might not be a future scheduler
        # step to trigger their completion.
        if self._req_status and all(
            rs.req.is_finished() for rs in self._req_status.values()
        ):
            self._current_batch_jobs_to_flush.update(self._jobs.keys())

        meta = OffloadingConnectorMetadata(
            load_jobs=self._current_batch_load_jobs,
            store_jobs=self._build_store_jobs(scheduler_output),
            jobs_to_flush=self._current_batch_jobs_to_flush,
        )
        self._current_batch_load_jobs = {}
        self._current_batch_jobs_to_flush = set()
        self._current_batch_allocated_block_ids = set()
        return meta

    def update_connector_output(self, connector_output: KVConnectorOutput):
        """
        Update KVConnector state from worker-side connectors output.

        Args:
            connector_output (KVConnectorOutput): the worker-side
                connectors output.
        """
        meta = connector_output.kv_connector_worker_meta
        if not isinstance(meta, OffloadingWorkerMetadata):
            assert meta is None
            meta = OffloadingWorkerMetadata()
        for job_id, count in meta.completed_jobs.items():
            assert count > 0
            if job_id < self._stale_job_threshold:
                logger.debug(
                    "Skipping stale completed job %d (pre-reset counter: %d)",
                    job_id,
                    self._stale_job_threshold,
                )
                continue
            job_status = self._jobs[job_id]
            if stats := meta.slackkv_completed_job_stats.get(job_id):
                transfer_time, transfer_bytes = stats
                job_status.slackkv_transfer_time_s = max(
                    job_status.slackkv_transfer_time_s, transfer_time
                )
                job_status.slackkv_transfer_bytes += transfer_bytes
            job_status.pending_count -= count
            if job_status.pending_count > 0:
                continue
            assert job_status.pending_count == 0

            req_status = self._req_status[job_status.req_id]
            if job_status.is_store:
                self.manager.complete_store(job_status.keys, req_status.req_context)
                if req_status.req.is_finished():
                    self._slackkv_trace_source_readiness(req_status)
            else:
                self.manager.complete_load(job_status.keys, req_status.req_context)
                if (req_status.req.kv_transfer_params or {}).get("slackkv_prefetch_only") is True:
                    phase3m = (req_status.req.kv_transfer_params or {}).setdefault("slackkv_phase3m", {})
                    phase3m.setdefault("T5", time.monotonic())
                req_status.slackkv_cpu_to_gpu_transfer_s = (
                    job_status.slackkv_transfer_time_s
                )
                req_status.slackkv_transfer_bytes = job_status.slackkv_transfer_bytes
                if self._blocks_being_loaded:
                    self._blocks_being_loaded.difference_update(job_status.keys)
            if self._block_id_to_pending_jobs:
                # Sliding window blocks are tracked from store creation
                # and must be cleaned up unconditionally.
                self._remove_pending_job(job_id, job_status.sliding_window_block_ids)
                # Non-sliding-window blocks are only tracked after
                # request_finished, so only clean up for finished requests.
                if req_status.req.is_finished():
                    self._remove_pending_job(
                        job_id, job_status.non_sliding_window_block_ids
                    )

            del self._jobs[job_id]
            req_status.transfer_jobs.remove(job_id)
            if not req_status.transfer_jobs and req_status.req.is_finished():
                del self._req_status[job_status.req_id]

    def request_finished(
        self,
        request: Request,
    ) -> tuple[bool, dict[str, Any] | None]:
        """
        Called when a request has finished, before its blocks are freed.

        Returns:
            True if the request is being saved/sent asynchronously and blocks
            should not be freed until the request_id is returned from
            get_finished().
            Optional KVTransferParams to be included in the request outputs
            returned by the engine.
        """
        # TODO(orozery): possibly kickoff offload for last block
        # which may have been deferred due to async scheduling
        req_status = self._req_status.get(request.request_id)

        req_context = (
            req_status.req_context if req_status else _create_req_context(request)
        )
        self.manager.on_request_finished(req_context)
        if req_status is not None:
            self._slackkv_trace_source_readiness(req_status)

        is_slackkv_prefetch = bool(
            request.kv_transfer_params
            and request.kv_transfer_params.get("slackkv_prefetch_only") is True
        )
        slackkv_result = None
        if is_slackkv_prefetch:
            if req_status is None:
                raise RuntimeError("SlackKV prefetch request lost connector state")
            slackkv_result = {
                "slackkv_prefetch": {
                    "status": "ok",
                    "external_tokens_loaded": (
                        req_status.slackkv_external_tokens_loaded
                    ),
                    "transfer_bytes": req_status.slackkv_transfer_bytes,
                    "cpu_to_gpu_transfer_ms": (
                        req_status.slackkv_cpu_to_gpu_transfer_s * 1000.0
                    ),
                    "model_forward_count": 0,
                    "generated_token_count": 0,
                }
            }

        if req_status is None:
            return False, None
        if not req_status.transfer_jobs:
            del self._req_status[request.request_id]
            return False, slackkv_result
        # Pending stores will outlive the request's block ownership.
        # Register them so future block reuse triggers a flush.
        for job_id in req_status.transfer_jobs:
            job_status = self._jobs[job_id]
            for bid in job_status.non_sliding_window_block_ids or ():
                self._block_id_to_pending_jobs.setdefault(bid, set()).add(job_id)
        return False, slackkv_result

    def take_events(self) -> Iterable[KVCacheEvent]:
        """Take the KV cache events from the connector.

        Returns:
            A list of KV cache events.
        """
        for event in self.manager.take_events():
            block_hashes = [get_offload_block_hash(key) for key in event.keys]
            if event.removed:
                yield BlockRemoved(block_hashes=block_hashes, medium=event.medium)
            else:
                yield BlockStored(
                    block_hashes=block_hashes,
                    parent_block_hash=None,
                    token_ids=[],
                    lora_id=None,
                    block_size=0,
                    medium=event.medium,
                    lora_name=None,
                )

    def reset_cache(self) -> None:
        """Reset the offloading manager cache, evicting all stored blocks."""

        # reset_cache cannot be called in the middle of a schedule step
        assert not self._current_batch_load_jobs
        assert not self._current_batch_jobs_to_flush
        assert not self._current_batch_allocated_block_ids

        # Flush all in-flight jobs
        self._current_batch_jobs_to_flush.update(self._jobs.keys())

        # Reset offloading manager cache
        self.manager.reset_cache()

        # Reset store progress so active requests re-offload from block 0
        for status in self._req_status.values():
            for group_state in status.group_states:
                group_state.next_stored_block_idx = 0

        # Discard jobs and save job_counter to be able to discard worker responses
        self._stale_job_threshold = self._job_counter
        self._jobs.clear()
        self._block_id_to_pending_jobs.clear()

        # Note: _current_batch_jobs_to_flush is intentionally NOT cleared.
        # The load flush IDs collected above must be delivered to workers.
        if self._blocks_being_loaded is not None:
            self._blocks_being_loaded.clear()

    def shutdown(self) -> None:
        self.manager.shutdown()
